import flet as ft
import flet_video as fv
import random as r
import time as t

def main(page: ft.Page):
    sourcepic = [
        "joke1.png", "joke2.png", "joke3.png", "joke4.png", "joke5.png", 
        "joke6.png", "joke7.png", "joke8.png", "joke9.png", "joke10.png", 
        "joke11.png", "joke12.png", "joke13.png", "joke14.png", "joke15.png", 
        "joke16.png","jokespecial.png"
    ]

    sample_media = [
        fv.VideoMedia("jokespecialvideo.mp4"),
        fv.VideoMedia("jokespecial2video.mp4"),
        fv.VideoMedia("jokespecial3video.mp4")
        ]

    blocker = ft.Container(
    width=page.width,
    height=page.height)
    imagesource = sourcepic[0]
    picture = ft.Image(src=imagesource)

    video = fv.Video(
            playlist=sample_media,
            expand=True,
            aspect_ratio=16 / 9,
            volume=100,
            autoplay=True) 

    stack =ft.Stack([video,blocker])
    realstack = ft.Container(      
            content = stack, 
            width=page.width,
            height=page.height)

    def HAHAHAHA(e):
        nonlocal imagesource
        r.shuffle(sourcepic)
        imagesource = sourcepic[0]
        picture.src = imagesource
        page.open(bs)
        page.update()

        if imagesource == "jokespecial.png":
            t.sleep(1)
            picture.src = "jokespecial1.png"
            page.update()

            t.sleep(2)
            picture.src = "jokespecial2.png"
            page.update()

            t.sleep(1)
            bs.content.content.controls.clear()
            page.overlay.append(realstack)
            page.update()

            t.sleep(70)
            page.overlay.remove(realstack)
            picture.src = "joke3.png"
            bs.content.content.controls.clear()
            bs.content.content.controls.append(
            ft.ElevatedButton("Dismiss", on_click=lambda _: page.close(bs))
        )
            bs.content.content.controls.append(picture)
            page.remove(video)
            page.update()

    def bs_dismissed(e):
        page.add(ft.Text("Bottom sheet dismissed"))

    button = ft.ElevatedButton(
        content=ft.Text("click me for a better joke", size=30),
        width=300,
        height=100,
        on_click=HAHAHAHA
    )

    bs = ft.BottomSheet(
        ft.Container(
            ft.Column(
                [
                    ft.ElevatedButton("Dismiss", on_click=lambda _: page.close(bs)), picture
                    
                ],
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                tight=True,
            ),
            padding=50,
        ),
        open=False,
        on_dismiss=bs_dismissed,
    )
    page.overlay.append(bs)
    page.add(
        button
    )


ft.app(main)
